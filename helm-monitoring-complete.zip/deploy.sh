#!/bin/bash
# Create namespace if it doesn't exist
kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -

# Add necessary helm repos
helm repo add grafana https://grafana.github.io/helm-charts
helm repo add open-telemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo update

# Deploy OpenTelemetry Collector
helm install otel-collector open-telemetry/opentelemetry-collector \
  --namespace monitoring \
  --values deployment/otel-collector-values.yaml

# Deploy Grafana with full provisioning
helm install grafana grafana/grafana \
  --namespace monitoring \
  --values deployment/grafana-values.yaml