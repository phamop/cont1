#!/bin/bash
set -e

# Create namespace if not exists
kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -

# Add necessary Helm repos
helm repo add grafana https://grafana.github.io/helm-charts
helm repo add open-telemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo update

# Install OpenTelemetry Collector
helm install otel-collector open-telemetry/opentelemetry-collector \
  --namespace monitoring \
  --values deployment/otel-collector-values.yaml

# Install Grafana with Workload Identity enabled
helm install grafana grafana/grafana \
  --namespace monitoring \
  --values deployment/grafana-values.yaml